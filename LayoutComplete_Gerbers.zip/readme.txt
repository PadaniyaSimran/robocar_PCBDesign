Readme.txt file for the Manufacturing directory.

Student Names: Simran Padaniya
Student Numbers: 868340
Phone Contact Information: 226-808-7218
Board Size: X-Dimensions 6"
	    Y-Dimensions 4"

link for FREEDFM Results:https://can01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fwww.freedfm.com%2Ffreedfm%2F0032914405557086%2Fresults%2Fsummary2.htm&amp;data=02%7C01%7Cspadaniya3460%40conestogac.on.ca%7Cdbbeee5601ec4260278c08d833ffbc7b%7C4ddd393ae98a4404841fc4becdd925a5%7C0%7C0%7C637316521185063709&amp;sdata=LgYvxNKM8jxmpHxcRhZfPqCPNQbn4%2B7QoyoiaxOjj3U%3D&amp;reserved=0