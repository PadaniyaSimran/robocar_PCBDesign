Readme.txt file for the Manufacturing directory.

Student Names: Simran Padaniya
Student Numbers: 868340
Phone Contact Information: 226-808-7218
Board Size: X-Dimensions 6"
	    Y-Dimensions 4"

